#!/bin/bash
set -e

echo "Removing old custom NGINX configs..."

rm -f /etc/nginx/conf.d/client_max_body_size.conf || true
rm -f /etc/nginx/conf.d/00_proxy.conf || true

echo "Cleanup complete."
