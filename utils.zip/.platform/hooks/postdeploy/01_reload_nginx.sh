#!/bin/bash
set -xe
sudo systemctl reload nginx
