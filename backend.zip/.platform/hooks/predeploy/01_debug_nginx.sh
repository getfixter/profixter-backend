#!/bin/bash
echo "Current nginx conf.d files:"
ls -l /etc/nginx/conf.d
